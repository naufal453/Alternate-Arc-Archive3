<?php $__currentLoopData = $post->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="deleteChapterModal<?php echo e($chapter->id); ?>" tabindex="-1" aria-labelledby="deleteChapterModalLabel<?php echo e($chapter->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('chapters.destroy', $chapter->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteChapterModalLabel<?php echo e($chapter->id); ?>">Delete Chapter</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete the chapter "<?php echo e($chapter->title); ?>"? This action cannot be undone.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/chapters/delete.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">

<?php $__env->startSection('content'); ?>
    <div class="content-area p-5 rounded">
        <h1 class="my-4 text-center">Search Results</h1>
        <form action="<?php echo e(route('search.results')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="query" class="form-control" placeholder="Search..."
                    value="<?php echo e(request('query')); ?>" required>
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>

        <?php if(isset($results) && $results->isNotEmpty()): ?>
            <div class="row row-cols-1 row-cols-md-2 g-4">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <!-- Card for larger devices -->
                        <div class="card d-none d-md-flex mb-3" style="width: 540px; margin-left: 20px;"
                            onclick="window.location='<?php echo e(route('posts.show', $result->id)); ?>'">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <?php if($result->image_path): ?>
                                        <img src="<?php echo e(asset('storage/' . $result->image_path)); ?>"
                                            class="img-fluid rounded-start" alt="Post Image"
                                            style="height: 250px; object-fit: cover;">
                                    <?php else: ?>
                                        <img src="..." class="img-fluid rounded-start" alt="Default Image"
                                            style="height: 100%; object-fit: cover;">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body d-flex flex-column">
                                        <h5 class="card-title"><?php echo e($result->title ?? 'Unknown Title'); ?></h5>
                                        <p class="card-text">
                                             <?php echo e(Str::limit(strip_tags(html_entity_decode($result->description)), 100)); ?>

                                        </p>
                                        <p class="card-text mt-auto">
                                            <small class="text-body-secondary">
                                                Created by
                                                <?php if($result->user): ?>
                                                    <a href="<?php echo e(route('user.show', ['username' => $result->user->username])); ?>"
                                                        class="user-link"><?php echo e($result->user->username); ?></a>
                                                <?php else: ?>
                                                    <span>Unknown User</span>
                                                <?php endif; ?>
                                                on <?php echo e($result->created_at->format('M d, Y')); ?>

                                            </small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Card for smaller devices -->
                        <div class="card d-md-none mb-3"
                            onclick="window.location='<?php echo e(route('posts.show', $result->id)); ?>'">
                            <?php if($result->image_path): ?>
                                <img src="<?php echo e(asset('storage/' . $result->image_path)); ?>" class="card-img-top"
                                    alt="Post Image">
                            <?php else: ?>
                                <img src="..." class="card-img-top" alt="Default Image">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($result->title ?? 'Unknown Title'); ?></h5>
                                <p class="card-text">
                                    <?php echo e(Str::limit($result->description ?? 'No description available', 100)); ?>

                                </p>
                                <p class="card-text">
                                    <small class="text-body-secondary">
                                        Created by
                                        <?php if($result->user): ?>
                                            <a href="<?php echo e(route('user.show', ['username' => $result->user->username])); ?>"
                                                class="user-link"><?php echo e($result->user->username); ?></a>
                                        <?php else: ?>
                                            <span>Unknown User</span>
                                        <?php endif; ?>
                                        on <?php echo e($result->created_at->format('M d, Y')); ?>

                                    </small>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif(isset($results)): ?>
            <p class="text-muted text-center">No results found for "<?php echo e(request('query')); ?>".</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/home/search.blade.php ENDPATH**/ ?>
<link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
<nav class="navbar bg-body-tertiary navbar-expand-lg fixed-top shadow p-3 mb-5 rounded"
    style="background-color: #6A9C89 !important; border-radius: 0px !important;">
    <div class="container-fluid">
        <!-- Brand -->
        <a class="navbar-brand d-flex align-items-center text-white" href="/">
            <img src="<?php echo e(asset('icon/book.png')); ?>" alt="Logo" class="brand-logo">
            <span class="logo-text ms-2">
                Alternate<br>
                Arc<br>
                Archive
            </span>
        </a>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
        <!-- Toggler/collapsible Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
            aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar content -->


        <div class="collapse navbar-collapse" id="navbarContent">
            <!-- Search Form (only on index.blade.php) -->
            <?php if(Route::is('home.index')): ?>
                <form id="search" class="d-flex me-auto mb-2 mb-lg-0" role="search"
                    action="<?php echo e(route('search.results')); ?>" method="GET">
                    <input class="form-control me-2" type="search" name="query"
                        style="background-color:#FFF5E4 !important;color:#6A9C89 !important;" placeholder="Search"
                        aria-label="Search" value="<?php echo e(request('query')); ?>">
                    
                </form>
            <?php endif; ?>

            <!-- Authenticated User Section -->
            <?php if(auth()->guard()->check()): ?>
                <div class="d-flex align-items-center ms-auto"> <!-- Add ms-auto to align to the right -->
                    <!-- Add Post Button -->
                    <?php if(Route::is('user.show') && auth()->id() === $user->id): ?>
                        <button id="createstory"
                            class="btn btn-primary btn-sm me-2 d-flex align-items-center create-story-btn" type="button"
                            data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-plus-circle me-1" viewBox="0 0 16 16">
                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16" />
                                <path
                                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4" />
                            </svg>
                            <span>Create Story</span>
                        </button>
                    <?php endif; ?>

                    <!-- User Dropdown -->
                    <div class="btn-group user-dropdown ms-auto" role="group">
                        <!-- Dropdown Button -->
                        <button class="btn btn-outline-dark btn-sm dropdown-toggle d-flex align-items-center" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                                class="bi bi-person-square me-2" viewBox="0 0 16 16">
                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                                <path
                                    d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z" />
                            </svg>
                            <span class="username"><?php echo e(auth()->user()->username); ?></span>
                        </button>

                        <!-- Dropdown Menu -->
                        <ul class="dropdown-menu dropdown-menu-end shadow" style="min-width: 200px;">
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('user.show', ['username' => auth()->user()->username])); ?>">
                                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item"
                                    href="<?php echo e(route('user.usersettings', ['username' => auth()->user()->username])); ?>">
                                    <i class="bi bi-gear me-2"></i> Settings
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a href="<?php echo e(route('logout.perform')); ?>" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Guest Section -->
            <?php if(auth()->guard()->guest()): ?>
                <div class="text-end ms-auto"> <!-- Add ms-auto to align to the right -->
                    <a href="<?php echo e(route('login.perform')); ?>" class="btn btn-outline-dark me-2">Login</a>
                    <a href="<?php echo e(route('register.perform')); ?>" class="btn btn-primary">Sign-up</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php echo $__env->make('home.post.add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>
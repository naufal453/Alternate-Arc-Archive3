<h3>Comments</h3>
<div class="comments-list" id="comments-list">
    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5><?php echo $comment->user->username; ?>

                    <?php if(Auth::id() === $comment->user_id): ?>
                        <span>(me)</span>
                    <?php endif; ?>
                </h5>
                <p><?php echo $comment->content; ?></p> <!-- Escape output -->
                <small><?php echo e($comment->created_at->format('d M Y, H:i')); ?></small>
                <br>
                
                <?php if(Auth::id() === $comment->user_id): ?>
                    <button class="btn btn-danger btn-sm" type="button" data-bs-toggle="modal"
                        data-bs-target="#deleteModal<?php echo e($comment->id); ?>">
                        Delete
                    </button>
                <?php endif; ?>

                
                <div class="modal fade" id="deleteModal<?php echo e($comment->id); ?>" tabindex="-1"
                    aria-labelledby="deleteModalLabel<?php echo e($comment->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteModalLabel<?php echo e($comment->id); ?>">Confirm Delete</h5>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to delete this comment?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p id="no-comments">No comments yet. Be the first to comment!</p>
    <?php endif; ?>
</div>


<form id="comment-form" action="<?php echo e(route('comments.store')); ?>" method="POST" class="mt-4" style="margin-bottom: 100px;">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="content" class="form-label">Add a Comment</label>
        <textarea name="content" id="content" class="form-control" rows="3" required></textarea>
    </div>
    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
    <button type="submit" class="btn btn-primary">Submit</button>
</form>


<script src="<?php echo e(asset('js/comments.js')); ?>"></script><?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/layouts/partials/comments.blade.php ENDPATH**/ ?>
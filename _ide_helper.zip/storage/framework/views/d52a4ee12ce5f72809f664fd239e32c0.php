<link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
<?php $__env->startSection('content'); ?>
    <div class="content-area p-5 rounded">
        <?php echo $__env->make('user.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('user.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/home/index.blade.php ENDPATH**/ ?>
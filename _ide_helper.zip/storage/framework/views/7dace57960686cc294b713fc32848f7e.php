<!-- filepath: c:\Users\TB\Documents\GitHub\Tech-Forum\resources\views\chapters\show.blade.php -->

<link rel="stylesheet" href="<?php echo e(asset('css/show.css')); ?>">
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e($chapter->title); ?></h1>
        <p><?php echo $chapter->content; ?></p> <!-- Render HTML content -->
        <small>Posted by <?php echo e($chapter->user->username ?? 'Unknown User'); ?> on
            <?php echo e($chapter->created_at->format('M d, Y')); ?></small>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/chapters/show.blade.php ENDPATH**/ ?>
<!-- Edit Post Modal -->
<div class="modal fade" id="editPostModal<?php echo e($post->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="editPostModalLabel<?php echo e($post->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="editPostModalLabel<?php echo e($post->id); ?>">Edit Story</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <!-- Title input -->
                    <div class="mb-3">
                        <input type="text" class="form-control" id="title" name="title"
                            value="<?php echo e($post->title); ?>" required />
                    </div>

                    <!-- Content textarea -->
                    <div class="mb-3">
                        <textarea class="form-control" id="description" name="description" rows="3" required><?php echo e((strip_tags(htmlspecialchars_decode($post->description)))); ?></textarea>
                    </div>

                    <!-- Submit button -->
                    <div class="text-end">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\TB\Documents\GitHub\Alternate-Arc-Archive3\resources\views/home/post/edit.blade.php ENDPATH**/ ?>